from clickbait.read_data import read_data
from clickbait.kfold_train_test import kfold_train_test
from clickbait.prepare_words import prepare_words
from clickbait.generate_wordcloud import generate_wordcloud
from clickbait.identify_clickbait import identify_clickbait

HEADLINE = "Apple Self Service Repair now offers 200 parts, tools, repair manuals, across EU"

output = {"display": {}}
output, data = read_data(output)
output, x_train, x_test, y_train, y_test = kfold_train_test(output, data)
(
    output,
    clickbait_words,
    legit_words,
    flat_list_clickbait,
    flat_list_legit,
) = prepare_words(output, x_train, y_train)
output = generate_wordcloud(output, flat_list_clickbait, flat_list_legit)
output = identify_clickbait(
    output,
    HEADLINE,
    x_train,
    x_test,
    y_train,
    y_test,
    clickbait_words,
    legit_words,
)
print(output)
