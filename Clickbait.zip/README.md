# COMP 5013 Project: Complete Backend Solution for Clickbait Detection using Naïve Bayes Classifier

## Pre-requisites

- Python 3.8 or higher
- numpy
- pandas
- matplotlib
- nltk
- wordcloud
- scikit-learn
- fastapi
- uvicorn

We'll also need to download the following NLTK packages -

- punkt
- stopwords

## Steps to execute the project

If you have all the requirements available, you may simply execute the following two files -

1. Run the model and check if a headline is clickbait or not as the output in the terminal

    ```bash
    python3 main_generic.py
    ```

    You can replace the default `HEADLINE` in the line 7 of the `main_generic.py` file.

2. Get the model attributes and generate the graphs and images

    ```bash
    python3 main_model_attrs.py
    ```

    This will generate output graphs and images in the `output` folder.

If you want to run the backend server, it is recommended you execute it system the right way, follow the steps below -

1. Create a virtual environment

    MAC OS / Linux

    ```bash
    python3 -m venv env
    ```

    Windows (cmd.exe)

    ```bash
    python -m venv env
    ```

2. Activate the virtual environment

    MAC OS / Linux

    ```bash
    source env/bin/activate
    ```

    Windows (cmd.exe)

    ```bash
    env\Scripts\activate
    ```

3. Install the requirements

    MAC OS Apple Silicon M1

    ```bash
    ARCHFLAGS="-arch arm64" pip3 install -r requirements.txt
    ```

    Intel

    ```bash
    pip install -r requirements.txt
    ```

    **Warning**: Scikit-learn 0.20 was the last version to support Python 2.7 and Python 3.4. Scikit-learn 0.21 supported Python 3.5-3.7. Scikit-learn 0.22 supported Python 3.5-3.8. Scikit-learn 0.23 - 0.24 require Python 3.6 or newer. Scikit-learn 1.0 supported Python 3.7-3.10. Scikit-learn 1.1 and later requires Python 3.8 or newer.

4. Run the application

    ```bash
    uvicorn main:app --reload
    ```

    It'll take a few seconds to start the server. Once the server is started, you'll see a similar message:

    ```bash
    INFO:     Will watch for changes in these directories: ['/Users/kartoon/Desktop/comp-5013-project']
    INFO:     Uvicorn running on http://127.0.0.1:8000 (Press CTRL+C to quit)
    INFO:     Started reloader process [42871] using StatReload
    [nltk_data] Downloading package punkt to /Users/kartoon/nltk_data...
    [nltk_data]   Package punkt is already up-to-date!
    [nltk_data] Downloading package stopwords to
    [nltk_data]     /Users/kartoon/nltk_data...
    [nltk_data]   Package stopwords is already up-to-date!
    INFO:     Started server process [42873]
    INFO:     Waiting for application startup.
    INFO:     Application startup complete.
    ```

5. Open the browser and go to [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs) to see the Swagger API documentation. You can use the Swagger UI to test the API. To do this you need to click on individual GET or POST API and then click on the "Try it out" button. You can then enter the required parameters and click on the "Execute" button to test the API. The output will be displayed in the "Response" section. NOTE: You need to have the application running in the background for this to work.

6. Open the browser and go to [http://127.0.0.1:8000/redoc](http://127.0.0.1:8000/redoc) to see the ReDoc API documentation.

7. To execute the APIs, you can also use the Postman application. There are two main endpoints available -

    The following endpoint checks if the headline is a clickbait or not. It returns a JSON that has all the information that a user must be provided with.

    ```bash
    POST http://127.0.0.1:8000/is-clickbait
    Request Body: {"headline": "Enter the headline here"}
    ```

    The following endpoint adds a new entry to the dataset. It returns a JSON response that tells us if the entry was made into the dataset or not.

    ```bash
    POST http://127.0.0.1:8000/add-entry
    Request Body: {"headline": "Enter the headline here", "is_clickbait": true}
    ```
