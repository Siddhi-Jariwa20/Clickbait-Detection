from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
from nltk.tokenize import word_tokenize

stop_words = set(stopwords.words())


def clean_message(message, stemmer=PorterStemmer()):
    # lowercase
    message = message.lower()
    # tokenize
    token_msg = word_tokenize(message)
    # remove stop words, punctuation, stemming
    filtered_words = []
    for word in token_msg:
        if (word not in stop_words) and word.isalpha():
            filtered_words.append(stemmer.stem(word))
    return filtered_words
