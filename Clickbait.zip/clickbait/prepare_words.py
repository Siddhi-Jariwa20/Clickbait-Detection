import pandas as pd

from clickbait.clean_message import clean_message


def prepare_words(output, x_train, y_train):
    nested_list = x_train.headline.apply(clean_message)

    nested_list.head()

    doc_ids_clickbait = x_train[y_train == 1].index
    doc_ids_legit = x_train[y_train == 0].index
    nested_list_clickbait = nested_list.loc[doc_ids_clickbait]
    nested_list_legit = nested_list.loc[doc_ids_legit]

    flat_list_clickbait = [
        item for sublist in nested_list_clickbait for item in sublist
    ]
    flat_list_legit = [item for sublist in nested_list_legit for item in sublist]
    legit_words = pd.Series(flat_list_legit).value_counts()
    clickbait_words = pd.Series(flat_list_clickbait).value_counts()

    output["n_unique_clickbait"] = clickbait_words.shape[0]
    output["n_unique_legit"] = legit_words.shape[0]
    output["display"][
        "n_unique_clickbait"
    ] = f"Unique words in clickbait headlines: {clickbait_words.shape[0]}"
    output["display"][
        "n_unique_legit"
    ] = f"Unique words in legit headlines: {legit_words.shape[0]}"
    output["common_words_clickbait"] = clickbait_words[:10].index.tolist()
    output["common_words_legit"] = legit_words[:10].index.tolist()

    return output, clickbait_words, legit_words, flat_list_clickbait, flat_list_legit
