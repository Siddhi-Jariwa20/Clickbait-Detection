import itertools
import time
import os

import numpy as np
import pandas as pd

from sklearn.metrics import confusion_matrix
from sklearn.metrics import f1_score, accuracy_score
from sklearn.metrics import roc_curve
from sklearn.metrics import precision_recall_curve
from sklearn.model_selection import learning_curve


import matplotlib.pyplot as plt

from clickbait.clean_message import clean_message


def identify_clickbait(
    output: dict,
    headline: str,
    x_train,
    x_test,
    y_train,
    y_test,
    clickbait_words,
    legit_words,
):
    output["headline"] = headline
    output["display"]["headline"] = headline

    start_time = time.process_time()
    cleaned_headline = clean_message(headline)
    end_time = time.process_time()
    print(f"Time taken to clean headline: {end_time - start_time} seconds")

    p_clickbait = y_train.value_counts(ascending=True)[1] / len(x_train)

    start_time = time.process_time()
    compound_prob = 1
    for word in cleaned_headline:
        try:
            word_in_clickbait = clickbait_words[word]
        except KeyError:
            word_in_clickbait = 0
        try:
            word_in_legit = legit_words[word]
        except KeyError:
            word_in_legit = 0
        p_word_if_bait = word_in_clickbait / y_train.value_counts(ascending=True)[1]
        p_word = (word_in_clickbait + word_in_legit) / len(x_train) or 0.0000001
        p_bait_if_word = p_word_if_bait * p_clickbait / p_word
        compound_prob = compound_prob * p_bait_if_word
    #     print(f"P(bait|{word}) =  \t{p_bait_if_word}")
    # print(f"\nP(this is bait) =  \t{compound_prob}")
    output["p_clickbait_compound_prob"] = compound_prob
    end_time = time.process_time()
    print(f"Time taken to calculate bait compound prob: {end_time - start_time} seconds")

    start_time = time.process_time()
    compound_prob = 1
    for word in cleaned_headline:
        try:
            word_in_clickbait = clickbait_words[word]
        except KeyError:
            word_in_clickbait = 0
        try:
            word_in_legit = legit_words[word]
        except KeyError:
            word_in_legit = 0
        p_word_if_legit = word_in_legit / y_train.value_counts(ascending=True)[1]
        p_word = (word_in_clickbait + word_in_legit) / len(x_train) or 0.0000001
        p_legit_if_word = p_word_if_legit * (1 - p_clickbait) / p_word
        compound_prob = compound_prob * p_legit_if_word
    #     print(f"P(legit|{word}) =  \t{p_legit_if_word}")
    # print(f"\nP(this is legit) =  \t{compound_prob}")
    output["p_legit_compound_prob"] = compound_prob
    end_time = time.process_time()
    print(f"Time taken to calculate legit compound prob: {end_time - start_time} seconds")

    start_time = time.process_time()
    clickbait_score = 0
    for word in cleaned_headline:
        try:
            word_in_clickbait = clickbait_words[word]
        except KeyError:
            word_in_clickbait = 0
        try:
            word_in_legit = legit_words[word]
        except KeyError:
            word_in_legit = 0
        p_word_if_bait = word_in_clickbait / y_train.value_counts(ascending=True)[1]
        p_word = (word_in_clickbait + word_in_legit) / len(x_train) or 0.0000001
        p_bait_if_word = p_word_if_bait * p_clickbait / p_word
        clickbait_score = clickbait_score + p_bait_if_word
    #     print(f"P(bait|{word}) =  \t{p_bait_if_word}")
    # print(f"\nclickbait score =  \t{clickbait_score}")
    output["clickbait_score"] = clickbait_score
    end_time = time.process_time()
    print(f"Time taken to calculate clickbait score: {end_time - start_time} seconds")

    start_time = time.process_time()
    legit_score = 0
    for word in cleaned_headline:
        try:
            word_in_clickbait = clickbait_words[word]
        except KeyError:
            word_in_clickbait = 0
        try:
            word_in_legit = legit_words[word]
        except KeyError:
            word_in_legit = 0
        p_word_if_legit = word_in_legit / y_train.value_counts(ascending=True)[1]
        p_word = (word_in_clickbait + word_in_legit) / len(x_train) or 0.0000001
        p_legit_if_word = p_word_if_legit * (1 - p_clickbait) / p_word
        legit_score = legit_score + p_legit_if_word
    #     print(f"P(legit|{word}) =  \t{p_legit_if_word}")
    # print(f"\nlegit score =  \t{legit_score}")
    output["legit_score"] = legit_score
    end_time = time.process_time()
    print(f"Time taken to calculate legit score: {end_time - start_time} seconds")

    start_time = time.process_time()
    certainty = round(clickbait_score / (clickbait_score + legit_score) * 100, 3)
    # print(f"The headline is a clickbait with a {certainty}% confidence")
    output["certainty"] = certainty
    output["display"][
        "certainty"
    ] = f"The headline is a clickbait with a {certainty}% confidence"

    clickbait_words_set = set(clickbait_words.index)
    legit_words_set = set(legit_words.index)
    all_words_list = list(set.union(clickbait_words_set, legit_words_set))
    # print(f"Unique words: {len(all_words_list)}")

    clickbait_occur = []
    legit_occur = []
    total_occur = []
    for word in all_words_list:

        a = legit_words.get(key=word)
        b = clickbait_words.get(key=word)

        if a is None:
            a = 0
        legit_occur.append(a)
        if b is None:
            b = 0
        clickbait_occur.append(b)
        total_occur.append(a + b)

    token_df = pd.DataFrame(
        list(zip(all_words_list, clickbait_occur, legit_occur, total_occur)),
        columns=["word", "clickbait_occur", "legit_occur", "total_occur"],
    )

    token_df.head()

    clickbait_occur_total = token_df["clickbait_occur"].sum()
    legit_occur_total = token_df["legit_occur"].sum()
    total_occur_total = clickbait_occur_total + legit_occur_total

    token_df["P_word_if_bait"] = token_df["clickbait_occur"] / clickbait_occur_total
    token_df["P_word_if_legit"] = token_df["legit_occur"] / legit_occur_total
    token_df["P_word"] = token_df["total_occur"] / total_occur_total

    token_df.head()

    token_df = token_df.drop(["clickbait_occur", "legit_occur", "total_occur"], axis=1)
    token_df.head()
    end_time = time.process_time()
    print(f"Time taken to generate token_df: {end_time - start_time} seconds")

    def is_clickbait(cleaned_headline):
        words = cleaned_headline
        clickbait_percentage = legit_percentage = 1
        for word in words:
            slice_df = token_df[
                token_df["word"] == word
            ]  # pylint: disable=unsubscriptable-object
            if slice_df.empty is False:
                P_word_if_bait = float(slice_df["P_word_if_bait"])
                P_word_if_legit = float(slice_df["P_word_if_legit"])
                P_word = float(slice_df["P_word"])
                clickbait_percentage += P_word_if_bait * p_clickbait / P_word
                legit_percentage += P_word_if_legit * (1 - p_clickbait) / P_word
        clickbait_chance = round(
            clickbait_percentage / (clickbait_percentage + legit_percentage) * 100, 3
        )
        return int(clickbait_percentage > legit_percentage), clickbait_chance

    start_time = time.process_time()
    verdict, confidence = is_clickbait(cleaned_headline)
    end_time = time.process_time()
    print(f"Time taken to find verdict: {end_time - start_time} seconds")
    output["verdict"] = bool(verdict)
    output["display"][
        "verdict"
    ] = f"Is it clickbait? {bool(verdict)} with confidence level: {confidence}%"

    return output
