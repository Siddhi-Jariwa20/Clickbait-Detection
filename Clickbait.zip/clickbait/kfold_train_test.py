from sklearn.model_selection import KFold
from sklearn.model_selection import train_test_split

def kfold_train_test(output: dict, data, n_splits=5, shuffle=True):
    target = data["clickbait"]
    features = data.drop("clickbait", axis=1)
    #### use k-fold cross validation
    kf = KFold(n_splits=n_splits, shuffle=shuffle)
    kf.get_n_splits(features)
    x_train = x_test = y_train = y_test = None
    for train_index, test_index in kf.split(features):
        x_train, x_test = features.iloc[train_index], features.iloc[test_index]
        y_train, y_test = target.iloc[train_index], target.iloc[test_index]
    output["n_splits"] = n_splits
    output["n_test"] = len(x_test)
    output["n_train"] = len(x_train)
    output["display"]["n_splits"] = f"{n_splits} fold cross validation is used"
    output["display"]["n_test"] = f"Length of the test dataset: {len(x_test)}"
    output["display"]["n_train"] = f"Length of the train dataset: {len(x_train)}"
    return output, x_train, x_test, y_train, y_test
