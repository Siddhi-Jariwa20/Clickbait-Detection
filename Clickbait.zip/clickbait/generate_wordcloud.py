import os

from wordcloud import WordCloud


def generate_wordcloud(output: dict, flat_list_clickbait, flat_list_legit):
    bait_str = " ".join(flat_list_clickbait).upper()
    wordcloud = WordCloud(width=2960, height=1665).generate(bait_str)
    wordcloud.to_file("output/clickbait.png")
    output["clickbait_wordcloud"] = os.path.abspath("output/clickbait.png")
    # plt.figure()
    # plt.imshow(wordcloud, interpolation="bilinear")
    # plt.axis("off")
    # plt.show()
    bait_str = " ".join(flat_list_legit).upper()
    wordcloud = WordCloud(width=2960, height=1665).generate(bait_str)
    wordcloud.to_file("output/legit.png")
    output["legit_wordcloud"] = os.path.abspath("output/legit.png")
    # plt.figure()
    # plt.imshow(wordcloud, interpolation="bilinear")
    # plt.axis("off")
    # plt.show()
    return output
