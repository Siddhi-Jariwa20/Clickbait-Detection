import pandas as pd
from sklearn.utils import shuffle


def read_data(output: dict):
    DATA_FILE = "clickbait_data.csv"

    data = pd.read_csv(DATA_FILE)
    n_entries = len(data)
    output["n_entries"] = n_entries
    output["display"][
        "n_entries"
    ] = f"The dataset consists of {n_entries} entries, out of which"

    data = shuffle(data)
    data.head()

    output["n_legit"] = sum(1 for v in dict(data["clickbait"]).values() if v == 0)
    output["n_clickbait"] = sum(1 for v in dict(data["clickbait"]).values() if v == 1)
    output["display"]["n_legit"] = f"{output['n_legit']} headlines in dataset are legit"
    output["display"][
        "n_clickbait"
    ] = f"{output['n_clickbait']} headlines in dataset are clickbait"

    return output, data
