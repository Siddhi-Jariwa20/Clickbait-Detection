import nltk

from fastapi import FastAPI
from fastapi.openapi.utils import get_openapi

from models.user_request import IsClickbait
from models.user_request import AddEntry

from clickbait.read_data import read_data
from clickbait.kfold_train_test import kfold_train_test
from clickbait.prepare_words import prepare_words
from clickbait.generate_wordcloud import generate_wordcloud
from clickbait.identify_clickbait import identify_clickbait

app = FastAPI()
output = data = x_train = x_test = y_train = y_test = None


def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema
    openapi_schema = get_openapi(
        title="Client Based Clickbait Detection API",
        version="1.0.0",
        description="This project is a part of COMP 5013 and is a client based clickbait detection API. It is a REST API that can be used to detect clickbait headlines. It is based on a Naive Bayes classifier trained on a dataset of 1000 clickbait headlines and 1000 legit headlines. The dataset was obtained from https://www.kaggle.com/amananandrai/clickbait-dataset. The API is built using FastAPI.",
        routes=app.routes,
    )
    openapi_schema["info"]["x-logo"] = {
        "url": "https://fastapi.tiangolo.com/img/logo-margin/logo-teal.png"
    }
    app.openapi_schema = openapi_schema
    return app.openapi_schema


def download_nltk():
    nltk.download("punkt")
    nltk.download("stopwords")


@app.get("/")
def init():
    return {"author": "Kartikey Bhardwaj", "message": "How you doin'?"}


@app.get("/hello")
def hello():
    return {"author": "Kartikey Bhardwaj", "message": "How you doin'?"}


@app.post("/is-clickbait")
def check_is_clickbait(request: IsClickbait):
    output = {"display": {}}
    output, data = read_data(output)
    output, x_train, x_test, y_train, y_test = kfold_train_test(output, data)
    (
        output,
        clickbait_words,
        legit_words,
        flat_list_clickbait,
        flat_list_legit,
    ) = prepare_words(output, x_train, y_train)
    output = generate_wordcloud(output, flat_list_clickbait, flat_list_legit)
    output = identify_clickbait(
        output,
        request.headline,
        x_train,
        x_test,
        y_train,
        y_test,
        clickbait_words,
        legit_words,
    )
    return output


@app.post("/add-entry")
def add_entry_to_dataset(request: AddEntry):
    headline = request.headline
    is_clickbait = 1 if request.is_clickbait else 0
    with open("clickbait_data.csv", "a") as f:
        f.write(f"{headline},{is_clickbait}\n")
    return {
        "message": "Entry added",
        "headline": headline,
        "is_clickbait": request.is_clickbait,
    }


app.openapi = custom_openapi

download_nltk()
