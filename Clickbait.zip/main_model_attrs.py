import os
import numpy as np
import pandas as pd
import itertools

import matplotlib.pyplot as plt

import nltk
from nltk.corpus import stopwords

from sklearn.metrics import confusion_matrix
from sklearn.metrics import f1_score
from sklearn.metrics import roc_curve
from sklearn.metrics import precision_recall_curve
from sklearn.model_selection import train_test_split
from sklearn.model_selection import learning_curve

from clickbait.read_data import read_data
from clickbait.kfold_train_test import kfold_train_test
from clickbait.prepare_words import prepare_words
from clickbait.clean_message import clean_message
from clickbait.generate_wordcloud import generate_wordcloud

nltk.download("stopwords")
nltk.download("punkt")

input_headline = (
    "Apple Self Service Repair now offers 200 parts, tools, repair manuals, across EU"
)

output = {"display": {}}
output, data = read_data(output)
output, x_train, x_test, y_train, y_test = kfold_train_test(output, data)
(
    output,
    clickbait_words,
    legit_words,
    flat_list_clickbait,
    flat_list_legit,
) = prepare_words(output, x_train, y_train)
output = generate_wordcloud(output, flat_list_clickbait, flat_list_legit)

p_clickbait = y_train.value_counts(ascending=True)[1] / len(x_train)

clickbait_score = 0
for word in clean_message(input_headline):
    try:
        word_in_clickbait = clickbait_words[word]
    except KeyError:
        word_in_clickbait = 0
    try:
        word_in_legit = legit_words[word]
    except KeyError:
        word_in_legit = 0
    p_word_if_bait = word_in_clickbait / y_train.value_counts(ascending=True)[1]
    p_word = (word_in_clickbait + word_in_legit) / len(x_train)
    p_bait_if_word = p_word_if_bait * p_clickbait / p_word
    clickbait_score = clickbait_score + p_bait_if_word

legit_score = 0
for word in clean_message(input_headline):
    try:
        word_in_clickbait = clickbait_words[word]
    except KeyError:
        word_in_clickbait = 0
    try:
        word_in_legit = legit_words[word]
    except KeyError:
        word_in_legit = 0
    p_word_if_legit = word_in_legit / y_train.value_counts(ascending=True)[1]
    p_word = (word_in_clickbait + word_in_legit) / len(x_train)
    p_legit_if_word = p_word_if_legit * (1 - p_clickbait) / p_word
    legit_score = legit_score + p_legit_if_word

certainty = round(clickbait_score / (clickbait_score + legit_score) * 100, 3)

clickbait_words_set = set(clickbait_words.index)
legit_words_set = set(legit_words.index)
all_words_list = list(set.union(clickbait_words_set, legit_words_set))

clickbait_occur = []
legit_occur = []
total_occur = []
for word in all_words_list:

    a = legit_words.get(key=word)
    b = clickbait_words.get(key=word)

    if a == None:
        a = 0
    legit_occur.append(a)
    if b == None:
        b = 0
    clickbait_occur.append(b)
    total_occur.append(a + b)

token_df = pd.DataFrame(
    list(zip(all_words_list, clickbait_occur, legit_occur, total_occur)),
    columns=["word", "clickbait_occur", "legit_occur", "total_occur"],
)

clickbait_occur_total = token_df["clickbait_occur"].sum()
legit_occur_total = token_df["legit_occur"].sum()
total_occur_total = clickbait_occur_total + legit_occur_total

token_df["P_word_if_bait"] = token_df["clickbait_occur"] / clickbait_occur_total
token_df["P_word_if_legit"] = token_df["legit_occur"] / legit_occur_total
token_df["P_word"] = token_df["total_occur"] / total_occur_total

token_df = token_df.drop(["clickbait_occur", "legit_occur", "total_occur"], axis=1)


def is_clickbait(headline):
    words = clean_message(headline)
    clickbait_percentage = legit_percentage = 1
    for word in words:
        slice_df = token_df[token_df["word"] == word]
        if slice_df.empty == False:
            P_word_if_bait = float(slice_df["P_word_if_bait"])
            P_word_if_legit = float(slice_df["P_word_if_legit"])
            P_word = float(slice_df["P_word"])
            clickbait_percentage += P_word_if_bait * p_clickbait / P_word
            legit_percentage += P_word_if_legit * (1 - p_clickbait) / P_word
    clickbait_chance = round(
        clickbait_percentage / (clickbait_percentage + legit_percentage) * 100, 3
    )
    return int(clickbait_percentage > legit_percentage), clickbait_chance


verdict, confidence = is_clickbait(input_headline)

y_test = np.array(y_test)

prediction = np.array([])
for index, row in x_test.iterrows():
    headline = row["headline"]
    verdict, certainty = is_clickbait(headline)
    prediction = np.append(prediction, verdict)

test_match_answer = np.equal(prediction, y_test)
unique_counts = np.unique(test_match_answer, return_counts=True)

result_df = pd.DataFrame(unique_counts[0], columns=["match"])
result_df["count"] = unique_counts[1]

guessed_right = int(result_df[result_df["match"] == True]["count"])
guessed_wrong = int(result_df[result_df["match"] == False]["count"])
category_names = ["Guessed right", "Guessed wrong"]
sizes = [guessed_right, guessed_wrong]
custom_colors = ["#70ef63", "#ff7675"]
plt.figure(figsize=[3, 3], dpi=150)
plt.pie(
    sizes,
    labels=category_names,
    textprops={"fontsize": 8},
    startangle=90,
    autopct="%1.0f%%",
    colors=custom_colors,
    pctdistance=0.8,
)
# draw circle
centre_circle = plt.Circle((0, 0), radius=0.6, fc="white")
plt.gca().add_artist(centre_circle)
plt.title("Test dataset prediction results")
plt.savefig("output/test_dataset_prediction_results.png", bbox_inches="tight")
print(
    "Test dataset prediction results:",
    os.path.abspath("output/test_dataset_prediction_results.png"),
)
# plt.show()

print(f"F1 score of the model {f1_score(y_test, prediction)}")

conf_matrix = confusion_matrix(y_true=y_test, y_pred=prediction)
plt.figure(figsize=[4, 4])
plt.imshow(conf_matrix, cmap="bone_r")
plt.title("Confusion matrix", fontsize=16)
plt.ylabel("Actual classes")
plt.xlabel("Predicted classes")
tick_marks = np.arange(2)
plt.yticks(tick_marks, [0, 1])
plt.xticks(tick_marks, [0, 1])
plt.colorbar()
for i, j in itertools.product(range(2), range(2)):
    plt.text(
        j,
        i,
        conf_matrix[i][j],
        horizontalalignment="center",
        color="white" if conf_matrix[i][j] > 200 else "black",
    )
plt.savefig("output/confusion_matrix.png", bbox_inches="tight")
print("Generated confusion matrix:", os.path.abspath("output/confusion_matrix.png"))

# draw ROC curve
fpr, tpr, thresholds = roc_curve(y_test, prediction)
plt.figure(figsize=[4, 4])
plt.plot(fpr, tpr, linewidth=2)
plt.plot([0, 1], [0, 1], "k--")
plt.axis([0, 1, 0, 1])
plt.xlabel("False Positive Rate", fontsize=16)
plt.ylabel("True Positive Rate", fontsize=16)
plt.title("ROC curve", fontsize=16)
plt.savefig("output/roc_curve.png", bbox_inches="tight")
print("Generated ROC curve:", os.path.abspath("output/roc_curve.png"))
# plt.show()

# draw precision-recall curve
precision, recall, thresholds = precision_recall_curve(y_test, prediction)
plt.figure(figsize=[4, 4])
plt.plot(recall, precision, "b-", linewidth=2)
plt.xlabel("Recall", fontsize=16)
plt.ylabel("Precision", fontsize=16)
plt.axis([0, 1, 0, 1])
plt.title("Precision-Recall curve", fontsize=16)
plt.savefig("output/precision_recall_curve.png", bbox_inches="tight")
print(
    "Generated precision-recall curve:",
    os.path.abspath("output/precision_recall_curve.png"),
)
# plt.show()

# draw a histogram of the prediction
plt.figure(figsize=[4, 4])
plt.hist(prediction, bins=2, color="#ff7675")
plt.title("Prediction histogram", fontsize=16)
plt.xlabel("Prediction", fontsize=16)
plt.ylabel("Count", fontsize=16)
plt.xticks([0, 1], ["Not clickbait", "Clickbait"])
plt.savefig("output/prediction_histogram.png", bbox_inches="tight")
print(
    "Generated prediction histogram:",
    os.path.abspath("output/prediction_histogram.png"),
)
# plt.show()

# draw a histogram of the actual
plt.figure(figsize=[4, 4])
plt.hist(y_test, bins=2, color="#70ef63")
plt.title("Actual histogram", fontsize=16)
plt.xlabel("Actual", fontsize=16)
plt.ylabel("Count", fontsize=16)
plt.xticks([0, 1], ["Not clickbait", "Clickbait"])
plt.savefig("output/actual_histogram.png", bbox_inches="tight")
print("Generated actual histogram:", os.path.abspath("output/actual_histogram.png"))
# plt.show()
