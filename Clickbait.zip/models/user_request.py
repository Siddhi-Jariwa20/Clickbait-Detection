from pydantic import BaseModel


class IsClickbait(BaseModel):
    headline: str


class AddEntry(BaseModel):
    headline: str
    is_clickbait: bool
